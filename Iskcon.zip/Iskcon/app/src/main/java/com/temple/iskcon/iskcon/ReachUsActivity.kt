package com.temple.iskcon.iskcon

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ReachUsActivity: AppCompatActivity() {
    var reachButton: Button?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reach_us)
        reachButton = findViewById(R.id.ReachButton)
    }
}
