package com.temple.iskcon.iskcon

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import android.widget.*
import com.firebase.client.Firebase
import kotlinx.android.synthetic.main.activity_bhoga.*

class BhogaActivity: AppCompatActivity() {
    var bhogaButton: Button?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        /*The saved instance state parameter is used to save the state of the activity for when the
        * activity is launched for the second time and onwards*/
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bhoga)
        var nameText: EditText = findViewById(R.id.editText)
        var spinBhoga = findViewById<Spinner>(R.id.spinnerBhoga)
        var spinCoun = findViewById<Spinner>(R.id.spinnerCoun)
        var spinSabzi =findViewById<Spinner>(R.id.spinnerSabzi)
        var spinRice = findViewById<Spinner>(R.id.spinnerRice)
        var spinSweets = findViewById<Spinner>(R.id.spinnerSweets)
        var spinParathas = findViewById<Spinner>(R.id.spinnerParathas)
        var spinLaddus = findViewById<Spinner>(R.id.spinnerLaddus)
        var spinamt = findViewById<Spinner>(R.id.amountSpinner)
        var spinday = findViewById<Spinner>(R.id.SpinnerDay)
        var subBhogaText: TextView = findViewById(R.id.bhoga_sub)
        var spinmonth = findViewById<Spinner>(R.id.SpinnerMonth)
        var spinyear = findViewById<Spinner>(R.id.SpinnerYear)
        bhogaButton = findViewById(R.id.button)
        var phoneText: EditText = findViewById(R.id.PhoneBhoga)
        var ref: Firebase = Firebase("https://iskcon-c16bc.firebaseio.com/Bhoga")


        val bhogaArray = arrayListOf<String>("Sabji", "Rice Preparation", "Sweets", "Parathas", "Laddus", "Cakes", "Salad",
                "Juice", "Pakode", "Snacks")

        initSpinner(spinBhoga,bhogaArray,this)


        val nameArray = arrayListOf("Rajeev", "Rahul", "Jaspreet", "Kirti", "Vijay")

        initSpinner(spinCoun, nameArray, this)

        val bhogaAmount = arrayListOf("1kg", "2kg", "3kg", "4kg", "5kg", "6kg", "7kg", "8kg", "9kg", "10kg")

        initSpinner(spinamt, bhogaAmount, this)

        val bhogaMonth = arrayListOf("January", "February", "March", "April", "May", "June", "July", "August",
                "September", "October", "November", "December")

        initSpinner(spinmonth, bhogaMonth, this)

        var bhogaYear: ArrayList<Int> = ArrayList()

        for (i in 2018..2030) {
            bhogaYear?.add(i)
        }

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bhogaYear)
        arrayAdapter.notifyDataSetChanged()
        spinyear.adapter = arrayAdapter

        spinyear.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        var bhogaTwentyEightDays: ArrayList<String> = ArrayList()

        for (i in 1..28) {
            bhogaTwentyEightDays?.add(i.toString())
        }

        var bhogaTwentyNineDays: ArrayList<String> = ArrayList()

        for (i in 1..29) {
            bhogaTwentyNineDays?.add(i.toString())
        }

        var bhogaThirtyDays: ArrayList<String> = ArrayList()

        for (i in 1..30) {
            bhogaThirtyDays?.add(i.toString())
        }

        var bhogaThirtyOneDays: ArrayList<String> = ArrayList()

        for (i in 1..31) {
            bhogaThirtyOneDays?.add(i.toString())
        }
        SpinnerYear.setSelection(0)
        SpinnerMonth.setSelection(0)
        initSpinner(spinday, bhogaThirtyOneDays, this@BhogaActivity)
        spinyear.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                spinmonth.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

                    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


                        var month: String = SpinnerMonth.selectedItem.toString()
                        var year: Int = Integer.parseInt(SpinnerYear.selectedItem.toString())

                        if (month == "January" || month == "March" || month == "May" || month == "July" || month == "August"
                                || month == "October" || month == "December") {
                            initSpinner(spinday, bhogaThirtyOneDays, this@BhogaActivity)
                        } else if (month == "April" || month == "June" || month == "September" || month == "November") {
                            initSpinner(spinday, bhogaThirtyDays, this@BhogaActivity)
                        } else if (month == "February" && year % 4 == 0) {
                            initSpinner(spinday, bhogaTwentyNineDays, this@BhogaActivity)
                         }else if (month == "February" && year % 4 != 0) {
                            initSpinner(spinday, bhogaTwentyEightDays, this@BhogaActivity)
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        // Code to perform some action when nothing is selected
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

       spinBhoga.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                    val sel: String = spinBhoga.getItemAtPosition(position).toString()
                if(sel == "Sabji") {

                    spinSabzi.visibility = View.VISIBLE
                    spinRice.visibility = View.INVISIBLE
                    spinSweets.visibility = View.INVISIBLE
                    spinParathas.visibility = View.INVISIBLE
                    spinLaddus.visibility = View.INVISIBLE
                    subBhogaText.visibility = View.VISIBLE
                    val bhogaSabzi = arrayListOf("Potato", "Bhindi", "Aloo Gobi", "Leafy Vegetable", "Paneer Sabzi", "Paneer+Palak")

                    initSpinner(spinSabzi, bhogaSabzi, this@BhogaActivity)
                }
                else if(sel == "Rice Preparation"){

                   spinSabzi.visibility = View.INVISIBLE
                    spinRice.visibility = View.VISIBLE
                    spinSweets.visibility = View.INVISIBLE
                    spinParathas.visibility = View.INVISIBLE
                    spinLaddus.visibility = View.INVISIBLE
                    subBhogaText.visibility = View.VISIBLE
                    val bhogaRice = arrayListOf("Kashmiri Pulav", "Veg Biryani", "Lemon Rice", "Jeera Rice", "Masala Rice",
                            "Moong Dal Khichdi", "Baby Corn Pulav")

                    initSpinner(spinRice, bhogaRice,this@BhogaActivity)
                }else if(sel == "Sweets"){

                    spinSabzi.visibility = View.INVISIBLE
                    spinRice.visibility = View.INVISIBLE
                    spinSweets.visibility = View.VISIBLE
                    spinParathas.visibility = View.INVISIBLE
                    spinLaddus.visibility = View.INVISIBLE
                    subBhogaText.visibility = View.VISIBLE
                    val bhogaSweets = arrayListOf("Balushahi","Gajar ka Halwa","Rasgulla","Gulab Jamun","Jalebi",
                            "Kalakand","Kheer","Sohan Papdi/Pateesa","Ras Malai","Coconut Barfi","Karji","Basundi","Shrikand",
                            "Anarse", "Modak","Puran Poli","Dudhi Halwa","Mahim Halwa")
                    initSpinner(spinSweets, bhogaSweets, this@BhogaActivity )
                }else if(sel == "Parathas"){

                    spinSabzi.visibility = View.INVISIBLE
                    spinRice.visibility = View.INVISIBLE
                    spinSweets.visibility = View.INVISIBLE
                    spinParathas.visibility = View.VISIBLE
                    spinLaddus.visibility = View.INVISIBLE
                    subBhogaText.visibility = View.VISIBLE
                    val bhogaParathas = arrayListOf("Palak Paratha","Pudina Paratha","Aloo Paratha","Aloo Gobi Paratha",
                            "Puri","Sweet Puri","Roti","Methi Paratha")

                    initSpinner(spinParathas, bhogaParathas, this@BhogaActivity)
                }else if(sel == "Laddus"){

                    spinSabzi.visibility = View.INVISIBLE
                    spinRice.visibility = View.INVISIBLE
                    spinSweets.visibility = View.INVISIBLE
                    spinParathas.visibility = View.INVISIBLE
                    spinLaddus.visibility = View.VISIBLE
                    subBhogaText.visibility = View.VISIBLE
                    val bhogaLaddus = arrayListOf("Rava Laddu","Besan Laddu","Dinkache Laddu","Bundi Laddu",
                            "Til Laddu","Badam Laddu","Atta Laddu","Churma Laddu")
                    initSpinner(spinLaddus, bhogaLaddus, this@BhogaActivity)
                }
                else{

                    spinSabzi.visibility = View.INVISIBLE
                    spinRice.visibility = View.INVISIBLE
                    spinSweets.visibility = View.INVISIBLE
                    spinParathas.visibility = View.INVISIBLE
                    spinLaddus.visibility = View.INVISIBLE
                    subBhogaText.visibility = View.INVISIBLE


                }

            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        bhogaButton?.setOnClickListener {
            Handler().postDelayed({

                var name: String = nameText.text.toString()
                var counsellor: String = spinnerCoun.selectedItem.toString()
                var bhoga: String = spinnerBhoga.selectedItem.toString()
                var phone: String = phoneText.text.toString()
                var amt: String = amountSpinner.selectedItem.toString()
                var day: String = SpinnerDay.selectedItem.toString()
                var month: String = SpinnerMonth.selectedItem.toString()
                var year: String = SpinnerYear.selectedItem.toString()
                var date: String = day+" "+month+", "+year
                var sub: String ?= null
                var abc: String?= null
                if(spinnerSabzi.visibility == View.VISIBLE){
                    abc = spinnerSabzi.selectedItem.toString()
                }else if(spinnerRice.visibility == View.VISIBLE){
                    abc = spinnerRice.selectedItem.toString()
                }else if(spinnerParathas.visibility == View.VISIBLE){
                    abc = spinnerParathas.selectedItem.toString()
                }else if(spinnerSweets.visibility == View.VISIBLE){
                    abc = spinnerSweets.selectedItem.toString()
                }else if(spinLaddus.visibility == View.VISIBLE){
                    abc = spinnerLaddus.selectedItem.toString()
                }

                sub = abc.toString()
                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(this, "Please enter your name", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(counsellor)) {
                    Toast.makeText(this, "Please enter Counsellor Name", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(phone)|| phone.length!=10) {
                    Toast.makeText(this, "Please enter valid phone number", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(bhoga)) {
                    Toast.makeText(this, "Please enter the Bhoga item", Toast.LENGTH_LONG).show()
                } else if(TextUtils.isEmpty(amt)){
                    Toast.makeText(this, "Please enter the amount of Bhoga item", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(day)){
                    Toast.makeText(this, "Please enter the Day", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(month)){
                    Toast.makeText(this, "Please enter the Month", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(year)){
                    Toast.makeText(this, "Please enter the Year", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(sub)){
                    Toast.makeText(this, "Please enter the Sub-Category", Toast.LENGTH_LONG).show()
                }
                else {

                    var id: String = ref.push().key
                    var bhog = Bhoga(name,counsellor,bhoga,phone,date,amt,sub)
                    ref.child(id).setValue(bhog)

                    Toast.makeText(this, "Bhoga is Registered", Toast.LENGTH_LONG).show()
                    nameText.setText("")
                    phoneText.setText("")
                    spinnerCoun.setSelection(0)
                    spinnerBhoga.setSelection(0)
                    Handler().postDelayed({
                        val startL = Intent(this@BhogaActivity,LauncherActivity::class.java)
                        startActivity(startL)
                        this.finish()
                    },100)
                }
            }, 1000)
        }

    }

}
fun initSpinner(spin: Spinner, arr: ArrayList<String>, context: Context ) {

    //val bhogaSabzi = arrayOf("Potato", "Bhindi", "Aloo Gobi", "Leafy Vegetable", "Paneer Sabzi", "Paneer+Palak")


    val arrayAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, arr)
    arrayAdapter.notifyDataSetChanged()
    spin.adapter = arrayAdapter

    spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

        override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


        }

        override fun onNothingSelected(parent: AdapterView<*>) {
            // Code to perform some action when nothing is selected
        }
    }
}
