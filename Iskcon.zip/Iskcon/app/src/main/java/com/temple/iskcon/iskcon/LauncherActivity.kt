package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class LauncherActivity: AppCompatActivity() {
    var sevaButton: Button?=null
    var bhogaButton: Button?=null
    var reachButton: Button?=null
    var logOutButton: Button?=null
    var upcomingButton: Button?=null
    var aboutButton: Button?= null

    /*var sevaButton: Button = findViewById(R.id.SevaButton)
    var bhogaButton: Button = findViewById(R.id.BhogButton)
    var reachButton: Button = findViewById(R.id.ReachButton)*/
    override fun onCreate(savedInstanceState: Bundle?) {
        /*The saved instance state parameter is used to save the state of the activity for when the
        * activity is launched for the second time and onwards*/
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launcher)


            sevaButton= findViewById(R.id.SevaButton)
            bhogaButton=findViewById(R.id.BhogButton)
            reachButton=findViewById(R.id.ReachButton)
            logOutButton = findViewById<Button>(R.id.LogOutButton)
            upcomingButton = findViewById(R.id.upcoming)
            aboutButton = findViewById(R.id.About)
            var mAuth: FirebaseAuth = FirebaseAuth.getInstance()
            sevaButton?.setOnClickListener{
            Handler().postDelayed({
                val startSeva = Intent(this@LauncherActivity,Seva::class.java)
                startActivity(startSeva)

            },10)

        }
        bhogaButton?.setOnClickListener{
            Handler().postDelayed({
                val startBhog = Intent(this@LauncherActivity,BhogaActivity::class.java)
                startActivity(startBhog)

            },10)
        }
        reachButton?.setOnClickListener{
            Handler().postDelayed({
                val startReach = Intent(this@LauncherActivity,ReachUsActivity::class.java)
                startActivity(startReach)

            },10)
        }

        upcomingButton?.setOnClickListener{
            Handler().postDelayed({
                val startUp = Intent(this@LauncherActivity,Upcoming::class.java)
                startActivity(startUp)

            },10)
        }

        aboutButton?.setOnClickListener{
            Handler().postDelayed({
                val startAbout = Intent(this@LauncherActivity,About::class.java)
                startActivity(startAbout)

            },10)
        }
        logOutButton?.setOnClickListener { view ->
            Toast.makeText(this, "Signing Out...", Toast.LENGTH_LONG).show()
            mAuth.signOut()

            mAuth.addAuthStateListener {
                if (mAuth.currentUser == null) {
                    this.finish()
                }
            }
            Handler().postDelayed({
                val startlog = Intent(this@LauncherActivity,RegLoginActivity::class.java)
                startActivity(startlog)

            },10)
        }


    }

}
