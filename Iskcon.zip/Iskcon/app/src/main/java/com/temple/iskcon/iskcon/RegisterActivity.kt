package com.temple.iskcon.iskcon

import android.app.ProgressDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.annotation.NonNull
import android.text.TextUtils
import android.view.View
import android.widget.*
import com.firebase.client.Firebase
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_bhoga.*
import kotlinx.android.synthetic.main.activity_register.*
import org.jetbrains.annotations.NotNull

class RegisterActivity : AppCompatActivity() {
    var regbtn: Button?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        var nameText: EditText = findViewById(R.id.name_reg)
        var phnText: EditText = findViewById(R.id.phone_reg)
        var emailText: EditText = findViewById(R.id.email)
        var passwordText: EditText = findViewById(R.id.password)
        var cnfmPasswordText: EditText = findViewById(R.id.cnfmPass)
        regbtn = findViewById(R.id.RegisterButton)
        val mAuth: FirebaseAuth = FirebaseAuth.getInstance()
        val databaseReference: DatabaseReference = FirebaseDatabase.getInstance().reference.child("Registrations")

        RegisterButton?.setOnClickListener {
            Handler().postDelayed({

                var name: String = nameText.text.toString()
                var phone: String = phnText.text.toString()
                var email: String = emailText.text.toString()
                var password: String = passwordText.text.toString()
                var cnfmPassword: String = cnfmPasswordText.text.toString()


                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(this, "Please enter your name", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(phone) && (phone.length < 10 || phone.length > 10)) {
                    Toast.makeText(this, "Please enter valid Phone Number", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(email) || !email.contains("@") || !(email.contains("rediffmail.com")
                        || email.contains("gmail.com") || email.contains("yahoo.com"))) {
                    Toast.makeText(this, "Please enter  valid Email ID", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(password) || (password.length < 8 && password.length > 16)) {
                    Toast.makeText(this, "Please enter the valid Password", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(cnfmPassword) || cnfmPassword != password) {
                    Toast.makeText(this, "Please enter the Password one more time", Toast.LENGTH_LONG).show()
                } else {

                    mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener{task: Task<AuthResult> ->
                        if (task.isSuccessful){
                            var user_id: String = mAuth.currentUser?.uid.toString()
                            var current_user: DatabaseReference = databaseReference.child(user_id)
                            current_user.child("Name").setValue(name)
                            current_user.child("Phone").setValue(phone)
                            val startLauncher = Intent(this@RegisterActivity,LoginActivity::class.java)
                            startActivity(startLauncher)
                            this.finish()
                    }
                    }


                }
            }, 1000)
        }


    }
    override fun onBackPressed() {
        super.onBackPressed()
        Handler().postDelayed({
           var startRegL = Intent(this@RegisterActivity,RegLoginActivity::class.java)
            startActivity(startRegL)
            this.finish()
        },1)
    }
}
