package com.temple.iskcon.iskcon

import android.content.Intent
import android.graphics.Color
import android.graphics.Rect
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.view.View
import android.widget.*
import com.firebase.client.Firebase
import android.widget.Spinner
import android.widget.TextView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.activity_seva.*
import java.util.ArrayList


class Seva: AppCompatActivity() {

    var submitButton: Button?=null


    override fun onCreate(savedInstanceState: Bundle?) {
        /*The saved instance state parameter is used to save the state of the activity for when the
        * activity is launched for the second time and onwards*/
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_seva)
        var ref: Firebase = Firebase("https://iskcon-c16bc.firebaseio.com/Users")
        val databaseReference = FirebaseDatabase.getInstance().getReference("Users")

        submitButton = findViewById(R.id.submitbutton)
        var nameText: EditText = findViewById(R.id.nameText)
        var phnText: EditText = findViewById(R.id.phnText)
        var spin = findViewById<Spinner>(R.id.spinnerSeva)
        var spinTime = findViewById<Spinner>(R.id.spinnerTime)
        var spinCounsellor = findViewById<Spinner>(R.id.spinnerCounsellor)
        var spinday = findViewById<Spinner>(R.id.SpinnerDay)
        var spinmonth = findViewById<Spinner>(R.id.SpinnerMonth)
        var spinyear = findViewById<Spinner>(R.id.SpinnerYear)

        val sevaNames = arrayOf("Garland Seva","Guest Reception","Cooking","Prasad Distribution","Discipline","Preaching")
        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sevaNames)
        spin.adapter = arrayAdapter
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        val sevaMonth = arrayListOf("January", "February", "March", "April", "May", "June", "July", "August",
                "September", "October", "November", "December")

        initSpinner(spinmonth, sevaMonth, this)

        var sevaYear: ArrayList<String> = ArrayList()

        for (i in 2018..2030) {
            sevaYear?.add(i.toString())
        }

        initSpinner(spinyear, sevaYear, this)

        var sevaTwentyEightDays: ArrayList<String> = ArrayList()

        for (i in 1..28) {
            sevaTwentyEightDays?.add(i.toString())
        }

        var sevaTwentyNineDays: ArrayList<String> = ArrayList()

        for (i in 1..29) {
            sevaTwentyNineDays?.add(i.toString())
        }

        var sevaThirtyDays: ArrayList<String> = ArrayList()

        for (i in 1..30) {
            sevaThirtyDays?.add(i.toString())
        }

        var sevaThirtyOneDays: ArrayList<String> = ArrayList()

        for (i in 1..31) {
            sevaThirtyOneDays?.add(i.toString())
        }
        SpinnerYear.setSelection(0)
        SpinnerMonth.setSelection(0)
        initSpinner(spinday, sevaThirtyOneDays, this@Seva)

        spinyear.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                spinmonth.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

                    override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


                        var month: String = SpinnerMonth.selectedItem.toString()
                        var year: Int = Integer.parseInt(SpinnerYear.selectedItem.toString())

                        if (month == "January" || month == "March" || month == "May" || month == "July" || month == "August"
                                || month == "October" || month == "December") {
                            initSpinner(spinday, sevaThirtyOneDays, this@Seva)
                        } else if (month == "April" || month == "June" || month == "September" || month == "November") {
                            initSpinner(spinday, sevaThirtyDays, this@Seva)
                        } else if (month == "February" && (year % 4) == 0) {
                            initSpinner(spinday, sevaTwentyNineDays, this@Seva)
                        } else if (month == "February" && (year % 4) != 0) {
                            initSpinner(spinday, sevaTwentyEightDays, this@Seva)
                        }
                    }

                    override fun onNothingSelected(parent: AdapterView<*>) {
                        // Code to perform some action when nothing is selected
                    }
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }



        val timeSlots = arrayOf("9:00 A.M to 12:00 P.M", "12:00 P.M to 3:00 P.M", "3:00 P.M to 6:00 P.M",
                "6:00 P.M to 9:00 P.M", "9:00 P.M to 12:00 P.M")
        val arrayAdapterTime = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, timeSlots)
        spinTime.adapter = arrayAdapterTime
        spinTime.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        val nameArray = arrayOf("Rajeev", "Rahul", "Jaspreet", "Kirti", "Vijay")

        val arrayAdapterCounsellor = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, nameArray)
        spinCounsellor.adapter = arrayAdapterCounsellor
        spinCounsellor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {

            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {


            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }



        submitButton?.setOnClickListener {
            Handler().postDelayed({

                var name: String = nameText.text.toString()
                var seva: String = spinnerSeva.selectedItem.toString()
                var phone: String = phnText.text.toString()
                var time: String = spinnerTime.selectedItem.toString()
                var counsellor: String = spinnerCounsellor.selectedItem.toString()
                var day: String = SpinnerDay.selectedItem.toString()
                var month: String = SpinnerMonth.selectedItem.toString()
                var year: String = SpinnerYear.selectedItem.toString()
                var date: String = day+" "+month+", "+year

                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(this, "Please enter your name", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(seva)) {
                    Toast.makeText(this, "Please enter Seva", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(phone) || phone.length!=10) {
                    Toast.makeText(this, "Please enter your phone number", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(time)) {
                    Toast.makeText(this, "Please enter the time slot", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(counsellor)) {
                    Toast.makeText(this, "Please enter the Counsellor Name", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(day)){
                    Toast.makeText(this, "Please enter the Day", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(month)){
                    Toast.makeText(this, "Please enter the Month", Toast.LENGTH_LONG).show()
                }else if(TextUtils.isEmpty(year)){
                    Toast.makeText(this, "Please enter the Year", Toast.LENGTH_LONG).show()
                } else {
                    var id: String = ref.push().key
                    var seva = Users(name, seva, phone, time, counsellor, date)
                    ref.child(id).setValue(seva)

                    Toast.makeText(this, "Seva Is alloted", Toast.LENGTH_LONG).show()
                    nameText.setText("")
                    phnText.setText("")
                    spinnerSeva.setSelection(0)
                    spinnerTime.setSelection(0)
                    spinnerCounsellor.setSelection(0)

                    Handler().postDelayed({
                        val startL = Intent(this@Seva,LauncherActivity::class.java)
                        startActivity(startL)
                        this.finish()
                    },100)
                }
            }, 1000)

        }
    }

}
