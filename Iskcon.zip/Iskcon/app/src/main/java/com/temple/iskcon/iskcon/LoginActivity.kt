package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import kotlinx.android.synthetic.main.activity_seva.*

class LoginActivity : AppCompatActivity() {

    var logInButton: Button?= null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val emailText: EditText = findViewById(R.id.email)
        val passwordText: EditText = findViewById(R.id.password)
        logInButton = findViewById<Button>(R.id.email_button)
        val mAuth: FirebaseAuth = FirebaseAuth.getInstance()
        val mDatabase: DatabaseReference = FirebaseDatabase.getInstance().reference.child("Registrations")

        logInButton?.setOnClickListener{
            Handler().postDelayed({
                var email: String = emailText.text.toString()
                var password: String = passwordText.text.toString()

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(this, "Please enter your Email Id", Toast.LENGTH_LONG).show()
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(this, "Please enter your Password", Toast.LENGTH_LONG).show()
                }else {
                    mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task: Task<AuthResult> ->
                        if (task.isSuccessful) {
                            var user_id: String = mAuth.currentUser?.uid.toString()
                            mDatabase.addValueEventListener(object : ValueEventListener {
                                override fun onCancelled(p0: DatabaseError) {

                                }

                                override fun onDataChange(p0: DataSnapshot) {
                                    if (p0.hasChild(user_id)) {
                                        //Handler().postDelayed({
                                            var logIntent = Intent(this@LoginActivity, LauncherActivity::class.java)
                                            //logIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                            //logIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            startActivity(logIntent)

                                        //}, 1000)
                                    } else {
                                        Toast.makeText(this@LoginActivity, "You need to setup your account", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                            this.finish()

                        }
                    }
                }

            },3500)
        }
    }
    override fun onBackPressed() {
        super.onBackPressed()
        val mAuth= FirebaseAuth.getInstance().currentUser
        if(mAuth != null){
            Handler().postDelayed({
                /*var loginIntent = Intent(this@LauncherActivity, LauncherActivity::class.java)
                startActivity(loginIntent)*/
                this.finish()
            },10)
        }else{
            Handler().postDelayed({
                var regIntent = Intent(this@LoginActivity, RegLoginActivity::class.java)
                startActivity(regIntent)
                this.finish()
            },10)
        }
    }
}