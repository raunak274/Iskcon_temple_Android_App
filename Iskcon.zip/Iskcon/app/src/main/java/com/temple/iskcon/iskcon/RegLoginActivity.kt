package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button

class RegLoginActivity : AppCompatActivity() {
    var logButton: Button?= null
    var regButton: Button?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg_login)
        logButton = findViewById(R.id.buttonLogin)
        regButton = findViewById(R.id.buttonRegister)
        logButton?.setOnClickListener{
            Handler().postDelayed({
                val startLog = Intent(this@RegLoginActivity,LoginActivity::class.java)
                startActivity(startLog)
                this.finish()
            },10)
        }
        regButton?.setOnClickListener{
            Handler().postDelayed({
                val startReg = Intent(this@RegLoginActivity,RegisterActivity::class.java)
                startActivity(startReg)
                this.finish()
            },10)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        this.finish()
    }
}
