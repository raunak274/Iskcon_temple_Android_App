package com.temple.iskcon.iskcon

import android.Manifest
import android.app.LauncherActivity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.ContextCompat.startActivity
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth


class SplashActivity : AppCompatActivity() {
    var mAuth: FirebaseAuth?= null
    var mAuthListener: FirebaseAuth.AuthStateListener?= null
    /*The SplashActivity file inherits the AppCompatActivity. AppCompatActivity is the base activity
        * on which every android application's activity is made upon.*/
    /*The Manifest class contains different permissions used in Android*/
    var permissionString = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE,/*This allows the
        application to read from external storage. This is required to read the songs on the device*/
            Manifest.permission.READ_PHONE_STATE,/*This gives the application access to get the
                cellular network information, phone state including the phone number, the status of any
                ongoing calls, and a list of any phone accounts registered on the device. This checks
                whether the phone is active of in flight mode.*/
            Manifest.permission.PROCESS_OUTGOING_CALLS)/*Allows the application to see the number
                dialled during an outgoing call and gives it the option to redirect or abort the call.
                Helps us in checking when a call is made so that we can pause the media player*/
    override fun onCreate(savedInstanceState: Bundle?) {
        /*The saved instance state parameter is used to save the state of the activity for when the
        * activity is launched for the sceond time and onwards*/
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        /*setContentView is used to set the view to the activity. R file is an auto-generated file
        * which contains the ids for each file present in our project. The layout directory is present
        * inside the R file and the activity_splash is present inside the layout directory*/
        /*Here we check if the user has granted all the permissions to the activity or not. If yes,
        * we execute the else block or else we execute the if block.*/
        if(!hasPermissions(this, *permissionString)){
            /*When the permissions are not granted, the application should ask for permissions.*/
            ActivityCompat.requestPermissions(this,permissionString,130)
            /*User requests for permissions by passing an array of permissions along with a unique
            * request code by which the request is identified*/
        }
        else{/*Handler is used to delay the tasks which are to be performed. Here we are delaying the
        opening of the next activity by 1 second in order to make the splash screen visible*/
            Handler().postDelayed({
                var startAct = Intent(this@SplashActivity, MainEmptyActivity::class.java )
                /*Source to destination activity*/
                startActivity(startAct)/*Used to launch new activity*/
                this.finish()/*Used to finish current activity*/
            },1000)

        }
        mAuth = FirebaseAuth.getInstance()
        mAuthListener = FirebaseAuth.AuthStateListener{

            fun onAuthStateChanged(firebaseAuth: FirebaseAuth){
                if(firebaseAuth.currentUser == null){
                    var loginIntent = Intent(this@SplashActivity, MainEmptyActivity::class.java)
                    startActivity(loginIntent)
                    //loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    this.finish()
                }

            }
        }

    }

   /*override fun onStart() {
        super.onStart()
        mAuth?.addAuthStateListener(mAuthListener)
    }*/
    /*This method is called when the user has completed the actions to be taken when the permissions
    * were asked for. Now, its time to check the result of the permissions request*/
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when(requestCode){
            130->{
                /*if request code is equal to 130*/
                /*Checks whether the permissions array is not empty and all the permissions have
                * been granted.*/
                if(grantResults.isNotEmpty()&& grantResults[0]== PackageManager.PERMISSION_GRANTED
                        && grantResults[1]== PackageManager.PERMISSION_GRANTED
                        && grantResults[2]== PackageManager.PERMISSION_GRANTED){
                    /*Same as above*/
                    Handler().postDelayed({
                        var startAct = Intent(this, MainEmptyActivity::class.java)
                        startActivity(startAct)
                        this.finish()
                    },1000)
                }
                else{
                    /*Message to be shown*/
                    Toast.makeText(this,"Please grant the permissions to continue", Toast.LENGTH_SHORT).show()
                }
                /*To return the control outside of the function*/
                return
            }
            else->{
                /*When something goes wrong with the Android OS, we would exit from the application
                * showing this message*/
                Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
                this.finish()
                /*To return the control outside of the function*/
                return
            }
        }
    }

}


/*Method to check if the permissions have been granted*/
fun hasPermissions(context: Context, vararg permissions: String): Boolean {
    /*Two parameters:- the context and array of permissions*/
    var hasAllPermissions = true
    /*Flag variable to check if the permissions have been granted or not*/
    for (p in permissions) {
        val res = context.checkCallingOrSelfPermission(p)
        /*This method is used to determine whether the permissions have been granted or not*/
        if (res != PackageManager.PERMISSION_GRANTED) {
            hasAllPermissions = false
            /*If any one permission has not been granted the value of the variable changes to
            * false, else it remains true*/
        }
    }
    return hasAllPermissions
/*The return statement returns the status of all permissions*/
}
