package com.temple.iskcon.iskcon

/*class RegistrationList(): ArrayAdapter<Registrations>(RegisterActivity, R.layout.activity_list_view){

    var context: Activity?= null
    var regList: List<Registrations>?=null

    init{

    }

    constructor(context: Activity, regList: List<Registrations>): this(){

        this.context = context
        this.regList = regList

    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var inflater: LayoutInflater = context!!.layoutInflater
        var listViewItem: View = inflater.inflate(R.layout.layout_textview,null,true)

        var textViewName: TextView = listViewItem.findViewById(R.id.textViewName)
        var textViewPhone: TextView = listViewItem.findViewById(R.id.textViewPhone)
        return super.getView(position, convertView, parent)
    }

}*/