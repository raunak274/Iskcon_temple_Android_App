package com.temple.iskcon.iskcon

class Bhoga(){
    var name: String?= null
    var phone: String?= null
    var counsellor: String?= null
    var bhoga:String?= null
    var date: String?= null
    var amt: String?= null
    var sub: String? =null
    constructor(name: String, counsellor: String, bhoga: String, phone: String, date: String, amt: String, sub: String): this(){
        this.name = name
        this.counsellor = counsellor
        this.phone = phone
        this.bhoga = bhoga
        this.date = date
        this.amt = amt
        this.sub = sub
    }

}