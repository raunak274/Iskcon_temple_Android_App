package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button

class Upcoming : AppCompatActivity() {
    var diwali: Button?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upcoming)
        diwali = findViewById(R.id.diwaliButton)
        diwali?.setOnClickListener{
            Handler().postDelayed({
                val startDiwali = Intent(this@Upcoming,Diwali::class.java)
                startActivity(startDiwali)

            },10)
        }
    }
}
