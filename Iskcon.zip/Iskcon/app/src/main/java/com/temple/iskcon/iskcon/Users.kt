package com.temple.iskcon.iskcon

class Users(){
    var name: String?= null
    var seva: String?= null
    var phn: String?= null
    var time: String?= null
    var counsellor: String?= null
    var date: String?= null

    init{

    }

    constructor(name: String,seva: String, phn: String, time: String, counsellor: String, date: String): this(){
        this.name = name
        this.seva = seva
        this.phn = phn
        this.time = time
        this.counsellor = counsellor
        this.date = date
    }

}