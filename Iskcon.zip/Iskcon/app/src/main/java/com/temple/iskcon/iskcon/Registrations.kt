package com.temple.iskcon.iskcon

class Registrations(){
    var name: String?= null
    var phone: String?= null
    var email: String?= null
    var password: String?= null
    var cnfmPassword: String?= null

    init{

    }

    constructor(name: String, phone: String, email: String, password: String, cnfmPassword: String): this(){
        this.name = name
        this.phone = phone
        this.email = email
        this.password = password
        this.cnfmPassword = cnfmPassword
    }

}