package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.firebase.client.utilities.Utilities
import com.google.firebase.auth.FirebaseAuth

class MainEmptyActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mAuth= FirebaseAuth.getInstance().currentUser
        if(mAuth != null){
            Handler().postDelayed({
                var loginIntent = Intent(this@MainEmptyActivity, LauncherActivity::class.java)
                startActivity(loginIntent)
                this.finish()
            },10)
        }else{
            Handler().postDelayed({
                var regIntent = Intent(this@MainEmptyActivity, About::class.java)
                startActivity(regIntent)
                this.finish()
            },10)
        }
    }
}

