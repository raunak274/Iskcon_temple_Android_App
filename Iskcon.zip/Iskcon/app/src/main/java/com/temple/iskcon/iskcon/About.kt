package com.temple.iskcon.iskcon

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import com.google.firebase.auth.FirebaseAuth
import kotlinx.android.synthetic.main.activity_about.*

class About : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)
        val mAuth= FirebaseAuth.getInstance().currentUser
        var skipButton  = findViewById<Button>(R.id.skipbutton)

        skipButton?.setOnClickListener{
            Handler().postDelayed({
                if(mAuth != null){
                    Handler().postDelayed({
                        var loginIntent = Intent(this@About, LauncherActivity::class.java)
                        startActivity(loginIntent)
                        this.finish()
                    },10)
                }else{
                    Handler().postDelayed({
                        var regIntent = Intent(this@About, RegLoginActivity::class.java)
                        startActivity(regIntent)
                        this.finish()
                    },10)
                }

            },10)
        }
    }
}
