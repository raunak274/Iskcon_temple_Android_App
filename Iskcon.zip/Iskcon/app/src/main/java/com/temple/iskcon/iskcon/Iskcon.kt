package com.temple.iskcon.iskcon

import android.app.Application
import android.support.multidex.MultiDexApplication
import com.firebase.client.Firebase

class Iskcon: MultiDexApplication(){

    override fun onCreate() {
        super.onCreate()
        Firebase.setAndroidContext(this)
    }
}