package com.temple.iskcon.iskcon

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Diwali : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diwali)
    }
}
